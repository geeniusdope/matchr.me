import { useState } from 'react';
import { Heart, Mail, Check, X, Copy, ArrowRight, Shield, User, Settings, LogOut, Pause, Play, UserPlus, Bell, Smartphone, Edit2 } from 'lucide-react';

type AuthScreen = 'welcome' | 'login' | 'register' | 'mobile-verification' | 'email-verification-sent';
type WorkEmailScreen = 'enter-email' | 'verification-pending' | 'verified';
type MainScreen = 'dashboard' | 'add-work-email' | 'add-interest' | 'matches' | 'settings';

interface MatchingEmail {
  id: string;
  email: string;
  verified: boolean;
  addedAt: Date;
}

interface UserProfile {
  firstName: string;
  surname: string;
  mobileNumber: string;
  personalEmail: string;
  matchingEmails: MatchingEmail[];
  isActive: boolean;
  isPaused: boolean;
  notifyViaPush: boolean;
  notifyViaEmail: boolean;
}

interface Interest {
  id: string;
  firstName: string;
  surname: string;
  email: string;
  timestamp: Date;
}

interface Match {
  id: string;
  firstName: string;
  surname: string;
  email: string;
  matchedAt: Date;
  mobileShared: boolean;
  isNew: boolean;
}

export default function App() {
  // Auth state
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authScreen, setAuthScreen] = useState<AuthScreen>('welcome');
  const [currentScreen, setCurrentScreen] = useState<MainScreen>('dashboard');

  // User profile
  const [userProfile, setUserProfile] = useState<UserProfile>({
    firstName: '',
    surname: '',
    mobileNumber: '',
    personalEmail: '',
    matchingEmails: [],
    isActive: false,
    isPaused: false,
    notifyViaPush: false,
    notifyViaEmail: false
  });

  // Registration form
  const [firstName, setFirstName] = useState('');
  const [surname, setSurname] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [personalEmail, setPersonalEmail] = useState('');
  const [password, setPassword] = useState('');

  // Login form
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Work email verification
  const [matchingEmailScreen, setMatchingEmailScreen] = useState<WorkEmailScreen>('enter-email');
  const [matchingEmail, setMatchingEmail] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [copiedCode, setCopiedCode] = useState(false);

  // Mobile verification
  const [mobileVerificationCode, setMobileVerificationCode] = useState('');
  const [enteredMobileCode, setEnteredMobileCode] = useState('');

  // Other state
  const [emailError, setEmailError] = useState('');
  const [interestFirstName, setInterestFirstName] = useState('');
  const [interestSurname, setInterestSurname] = useState('');
  const [interestEmail, setInterestEmail] = useState('');
  const [editingInterestId, setEditingInterestId] = useState<string | null>(null);
  const [showSuccess, setShowSuccess] = useState(false);

  // Mock data for prototype
  const [interests, setInterests] = useState<Interest[]>([
    { id: '1', firstName: 'Sarah', surname: 'Johnson', email: 'sarah.johnson@company.com', timestamp: new Date(Date.now() - 86400000) },
    { id: '2', firstName: 'Mike', surname: 'Chen', email: 'mike.chen@company.com', timestamp: new Date(Date.now() - 172800000) }
  ]);

  const [matches, setMatches] = useState<Match[]>([
    { id: '1', firstName: 'Alex', surname: 'Rivera', email: 'alex.rivera@company.com', matchedAt: new Date(Date.now() - 259200000), mobileShared: false, isNew: false },
    { id: '2', firstName: 'Emma', surname: 'Wilson', email: 'emma.wilson@company.com', matchedAt: new Date(Date.now() - 3600000), mobileShared: false, isNew: true },
    { id: '3', firstName: 'James', surname: 'Chen', email: 'james.chen@university.edu', matchedAt: new Date(Date.now() - 7200000), mobileShared: false, isNew: true }
  ]);

  const validateEmail = (email: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const generateVerificationCode = () => {
    // Generate a 6-digit code
    return Math.floor(100000 + Math.random() * 900000).toString();
  };

  const handleRegister = () => {
    if (!firstName.trim() || !surname.trim()) {
      setEmailError('Please enter your first name and surname');
      return;
    }
    if (!mobileNumber.trim()) {
      setEmailError('Please enter your mobile number');
      return;
    }
    if (!validateEmail(personalEmail)) {
      setEmailError('Please enter a valid email address');
      return;
    }
    if (!password || password.length < 6) {
      setEmailError('Password must be at least 6 characters');
      return;
    }

    setEmailError('');
    // In production, this would send SMS code
    const code = generateVerificationCode();
    setMobileVerificationCode(code);
    setAuthScreen('mobile-verification');
  };

  const handleVerifyMobile = () => {
    if (enteredMobileCode !== mobileVerificationCode) {
      setEmailError('Invalid code. Please try again.');
      return;
    }
    setEmailError('');
    setEnteredMobileCode('');
    // In production, this would create the account and send verification email
    setAuthScreen('email-verification-sent');
  };

  const handleLogin = () => {
    if (!loginEmail.trim()) {
      setEmailError('Please enter your email address');
      return;
    }
    if (!validateEmail(loginEmail)) {
      setEmailError('Please enter a valid email address');
      return;
    }
    if (!loginPassword.trim()) {
      setEmailError('Please enter your password');
      return;
    }

    setEmailError('');

    // Mock login - in production, this would authenticate with backend
    setUserProfile({
      firstName: 'Sarah',
      surname: 'Johnson',
      mobileNumber: '+1 555-0123',
      personalEmail: loginEmail,
      matchingEmails: [],
      isActive: true,
      isPaused: false,
      notifyViaPush: false,
      notifyViaEmail: false
    });
    setIsAuthenticated(true);
    setCurrentScreen('dashboard');
  };

  const handleWorkEmailSubmit = () => {
    if (!validateEmail(matchingEmail)) {
      setEmailError('Please enter a valid email address');
      return;
    }

    // Check if email is already added
    if (userProfile.matchingEmails.some(e => e.email.toLowerCase() === matchingEmail.toLowerCase())) {
      setEmailError('This email has already been added');
      return;
    }

    setEmailError('');
    const code = generateVerificationCode();
    setVerificationCode(code);
    setMatchingEmailScreen('verification-pending');
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(verificationCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleWorkEmailVerified = () => {
    // In production, this would be triggered by backend when email is received
    const newMatchingEmail: MatchingEmail = {
      id: Date.now().toString(),
      email: matchingEmail,
      verified: true,
      addedAt: new Date()
    };

    setUserProfile({
      ...userProfile,
      matchingEmails: [...userProfile.matchingEmails, newMatchingEmail]
    });
    setMatchingEmailScreen('verified');
    setTimeout(() => {
      setCurrentScreen('dashboard');
      setMatchingEmail('');
      setMatchingEmailScreen('enter-email');
    }, 2000);
  };

  const handleTogglePause = () => {
    setUserProfile({
      ...userProfile,
      isPaused: !userProfile.isPaused
    });
  };

  const handleToggleNotification = (type: 'push' | 'email') => {
    if (type === 'push') {
      setUserProfile({
        ...userProfile,
        notifyViaPush: !userProfile.notifyViaPush
      });
    } else {
      setUserProfile({
        ...userProfile,
        notifyViaEmail: !userProfile.notifyViaEmail
      });
    }
  };

  const handleRemoveMatchingEmail = (id: string) => {
    setUserProfile({
      ...userProfile,
      matchingEmails: userProfile.matchingEmails.filter(e => e.id !== id)
    });
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setAuthScreen('welcome');
    setCurrentScreen('dashboard');
    setUserProfile({
      firstName: '',
      surname: '',
      mobileNumber: '',
      personalEmail: '',
      matchingEmails: [],
      isActive: false,
      isPaused: false,
      notifyViaPush: false,
      notifyViaEmail: false
    });
  };

  const handleAddInterest = () => {
    if (!interestFirstName.trim() || !interestSurname.trim()) {
      setEmailError('Please enter their first name and surname');
      return;
    }

    if (!validateEmail(interestEmail)) {
      setEmailError('Please enter a valid email address');
      return;
    }

    // Check if trying to add one of their own matching emails
    if (userProfile.matchingEmails.some(e => e.email.toLowerCase() === interestEmail.toLowerCase())) {
      setEmailError('You cannot add yourself');
      return;
    }

    if (interests.some(i => i.email === interestEmail && i.id !== editingInterestId)) {
      setEmailError('You already expressed interest in this person');
      return;
    }

    setEmailError('');

    if (editingInterestId) {
      // Update existing interest
      setInterests(interests.map(interest =>
        interest.id === editingInterestId
          ? { ...interest, firstName: interestFirstName, surname: interestSurname, email: interestEmail }
          : interest
      ));
      setEditingInterestId(null);
    } else {
      // Add new interest
      setInterests([...interests, {
        id: Date.now().toString(),
        firstName: interestFirstName,
        surname: interestSurname,
        email: interestEmail,
        timestamp: new Date()
      }]);
    }

    setInterestFirstName('');
    setInterestSurname('');
    setInterestEmail('');
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
  };

  const handleEditInterest = (interest: Interest) => {
    setEditingInterestId(interest.id);
    setInterestFirstName(interest.firstName);
    setInterestSurname(interest.surname);
    setInterestEmail(interest.email);
    setEmailError('');
  };

  const handleCancelEdit = () => {
    setEditingInterestId(null);
    setInterestFirstName('');
    setInterestSurname('');
    setInterestEmail('');
    setEmailError('');
  };

  const handleDeleteInterest = (id: string) => {
    setInterests(interests.filter(interest => interest.id !== id));
    if (editingInterestId === id) {
      handleCancelEdit();
    }
  };

  const handleShareMobile = (matchId: string) => {
    setMatches(matches.map(match =>
      match.id === matchId
        ? { ...match, mobileShared: !match.mobileShared }
        : match
    ));
  };

  const handleMarkAsRead = (matchId: string) => {
    setMatches(matches.map(match =>
      match.id === matchId
        ? { ...match, isNew: false }
        : match
    ));
  };


  // If authenticated, show main app screens
  if (isAuthenticated) {
    // Dashboard Screen
    if (currentScreen === 'dashboard') {
      return (
        <div className="size-full bg-gray-50 flex flex-col max-w-md mx-auto">
          {/* Header */}
          <header className="bg-white border-b border-gray-200 px-4 py-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <div className="bg-pink-500 text-white p-2 rounded-full">
                  <Heart size={20} fill="currentColor" />
                </div>
                <h1 className="text-xl font-bold text-gray-900">Dashboard</h1>
              </div>
              <button
                onClick={() => setCurrentScreen('settings')}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <Settings size={24} className="text-gray-600" />
              </button>
            </div>
            <p className="text-sm text-gray-600">
              Hi, {userProfile.firstName} {userProfile.surname}
            </p>
          </header>

          {/* Main Content */}
          <main className="flex-1 overflow-y-auto p-4 space-y-3">
            {/* Matching Email Status */}
            {userProfile.matchingEmails.length === 0 && (
              <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg">
                <p className="text-sm font-medium text-yellow-900 mb-2">
                  Add a matching email to start matching
                </p>
                <button
                  onClick={() => setCurrentScreen('add-work-email')}
                  className="text-sm text-yellow-700 font-medium hover:underline"
                >
                  Add matching email →
                </button>
              </div>
            )}

            {/* Pause/Unpause Status */}
            {userProfile.isPaused && userProfile.matchingEmails.length > 0 && (
              <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg">
                <p className="text-sm font-medium text-blue-900">
                  Matching is currently paused
                </p>
              </div>
            )}

            {/* Dashboard Actions */}
            <div className="space-y-3">
              <button
                onClick={() => setCurrentScreen('add-work-email')}
                className="w-full bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className="bg-purple-100 p-3 rounded-lg">
                    <Shield size={24} className="text-purple-600" />
                  </div>
                  <div className="text-left">
                    <p className="font-medium text-gray-900">
                      {userProfile.matchingEmails.length > 0 ? 'Manage Matching Emails' : 'Add Matching Email'}
                    </p>
                    <p className="text-sm text-gray-500">
                      {userProfile.matchingEmails.length > 0
                        ? `${userProfile.matchingEmails.length} email${userProfile.matchingEmails.length > 1 ? 's' : ''} added`
                        : 'Required to start matching'}
                    </p>
                  </div>
                </div>
                <ArrowRight size={20} className="text-gray-400" />
              </button>

              <button
                onClick={() => setCurrentScreen('add-interest')}
                disabled={userProfile.matchingEmails.length === 0}
                className={`w-full bg-white p-4 rounded-lg shadow-sm transition-shadow flex items-center justify-between ${
                  userProfile.matchingEmails.length > 0
                    ? 'hover:shadow-md'
                    : 'opacity-50 cursor-not-allowed'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="bg-pink-100 p-3 rounded-lg">
                    <Heart size={24} className="text-pink-600" />
                  </div>
                  <div className="text-left">
                    <p className="font-medium text-gray-900">Manage Interests</p>
                    <p className="text-sm text-gray-500">{interests.length} {interests.length === 1 ? 'interest' : 'interests'} recorded</p>
                  </div>
                </div>
                <ArrowRight size={20} className="text-gray-400" />
              </button>

              <button
                onClick={() => setCurrentScreen('matches')}
                disabled={userProfile.matchingEmails.length === 0}
                className={`w-full bg-white p-4 rounded-lg shadow-sm transition-shadow flex items-center justify-between ${
                  userProfile.matchingEmails.length > 0
                    ? 'hover:shadow-md'
                    : 'opacity-50 cursor-not-allowed'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="bg-green-100 p-3 rounded-lg">
                    <Check size={24} className="text-green-600" />
                  </div>
                  <div className="text-left">
                    <p className="font-medium text-gray-900">View Matches</p>
                    <p className="text-sm text-gray-500">{matches.length} mutual matches</p>
                  </div>
                </div>
                <ArrowRight size={20} className="text-gray-400" />
              </button>

              <button
                onClick={handleTogglePause}
                disabled={userProfile.matchingEmails.length === 0}
                className={`w-full bg-white p-4 rounded-lg shadow-sm transition-shadow flex items-center justify-between ${
                  userProfile.matchingEmails.length > 0
                    ? 'hover:shadow-md'
                    : 'opacity-50 cursor-not-allowed'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`${userProfile.isPaused ? 'bg-orange-100' : 'bg-blue-100'} p-3 rounded-lg`}>
                    {userProfile.isPaused ? (
                      <Play size={24} className="text-orange-600" />
                    ) : (
                      <Pause size={24} className="text-blue-600" />
                    )}
                  </div>
                  <div className="text-left">
                    <p className="font-medium text-gray-900">
                      {userProfile.isPaused ? 'Resume Matching' : 'Pause Matching'}
                    </p>
                    <p className="text-sm text-gray-500">
                      {userProfile.isPaused ? 'Start matching again' : 'Temporarily stop matching'}
                    </p>
                  </div>
                </div>
                <ArrowRight size={20} className="text-gray-400" />
              </button>

              <button
                onClick={handleLogout}
                className="w-full bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className="bg-gray-100 p-3 rounded-lg">
                    <LogOut size={24} className="text-gray-600" />
                  </div>
                  <div className="text-left">
                    <p className="font-medium text-gray-900">Log Out</p>
                    <p className="text-sm text-gray-500">Sign out of your account</p>
                  </div>
                </div>
                <ArrowRight size={20} className="text-gray-400" />
              </button>
            </div>
          </main>
        </div>
      );
    }

    // Add/Verify Work Email Screen
    if (currentScreen === 'add-work-email') {
      if (matchingEmailScreen === 'enter-email') {
        return (
          <div className="size-full bg-gray-50 flex flex-col max-w-md mx-auto overflow-y-auto">
            <header className="bg-white border-b border-gray-200 px-4 py-4 flex items-center gap-3">
              <button onClick={() => setCurrentScreen('dashboard')} className="p-2 hover:bg-gray-100 rounded-lg">
                <X size={20} />
              </button>
              <h1 className="text-lg font-semibold text-gray-900">Manage Matching Emails</h1>
            </header>

            <main className="flex-1 px-6 py-6">
              {/* Show existing matching emails if any */}
              {userProfile.matchingEmails.length > 0 && (
                <div className="mb-8">
                  <h3 className="font-semibold text-lg mb-3">Your Matching Emails ({userProfile.matchingEmails.length})</h3>
                  <div className="space-y-3">
                    {userProfile.matchingEmails.map((email) => (
                      <div key={email.id} className="bg-white p-4 rounded-lg shadow-sm flex items-center justify-between">
                        <div className="flex-1">
                          <p className="font-medium text-gray-900">{email.email}</p>
                          <p className="text-xs text-gray-500 mt-0.5">
                            {email.type === 'work' ? 'Work' : 'University'} • Added {email.addedAt.toLocaleDateString()}
                          </p>
                        </div>
                        <button
                          onClick={() => handleRemoveMatchingEmail(email.id)}
                          className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                        >
                          <X size={20} />
                        </button>
                      </div>
                    ))}
                  </div>
                  <div className="border-t border-gray-200 my-6"></div>
                </div>
              )}

              <div className="flex flex-col items-center">
                <div className="bg-purple-500 text-white p-6 rounded-full mb-8">
                  <Shield size={48} />
                </div>

                <h2 className="text-2xl font-bold text-gray-900 mb-2 text-center">Add Matching Email</h2>
                <p className="text-gray-600 text-center mb-8">
                  Add and verify your work or university email to enable matching
                </p>

                <div className="w-full space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Email address
                    </label>
                    <input
                      type="email"
                      value={matchingEmail}
                      onChange={(e) => setMatchingEmail(e.target.value)}
                      placeholder="you@company.com"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none"
                    />
                    {emailError && <p className="text-red-500 text-sm mt-1">{emailError}</p>}
                  </div>

                  <button
                    onClick={handleWorkEmailSubmit}
                    className="w-full bg-purple-500 text-white py-3 rounded-lg font-semibold hover:bg-purple-600 transition-colors flex items-center justify-center gap-2"
                  >
                    Get Verification Code
                    <ArrowRight size={20} />
                  </button>
                </div>

                <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg mt-8 w-full">
                  <p className="text-sm text-blue-900">
                    <strong>Next step:</strong> You'll receive a verification code to send from your email
                  </p>
                </div>
              </div>
            </main>
          </div>
        );
      }

      if (matchingEmailScreen === 'verification-pending') {
        return (
          <div className="size-full bg-gray-50 flex flex-col max-w-md mx-auto overflow-y-auto">
            <header className="bg-white border-b border-gray-200 px-4 py-4 flex items-center gap-3 sticky top-0 z-10">
              <button onClick={() => {
                setMatchingEmailScreen('enter-email');
                setCurrentScreen('dashboard');
              }} className="p-2 hover:bg-gray-100 rounded-lg">
                <X size={20} />
              </button>
              <h1 className="text-lg font-semibold text-gray-900">Verify Matching Email</h1>
            </header>

            <main className="flex-1 flex flex-col items-center justify-center px-6 py-8">
              <div className="bg-green-500 text-white p-6 rounded-full mb-8">
                <Mail size={48} />
              </div>

              <h2 className="text-2xl font-bold text-gray-900 mb-2 text-center">Send Verification Email</h2>
              <p className="text-gray-600 text-center mb-8">
                Follow these steps to verify your email
              </p>

              <div className="w-full bg-white p-6 rounded-lg shadow-sm space-y-6">
                <div className="space-y-4">
                  <div className="flex gap-3">
                    <div className="flex-shrink-0 w-8 h-8 bg-pink-500 text-white rounded-full flex items-center justify-center font-bold text-sm">
                      1
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-gray-900 mb-1">Copy your verification code</p>
                      <div className="bg-gray-50 border-2 border-dashed border-gray-300 rounded-lg p-4 flex items-center justify-between">
                        <code className="text-2xl font-bold text-pink-600 tracking-wider">
                          {verificationCode}
                        </code>
                        <button
                          onClick={handleCopyCode}
                          className="p-2 text-gray-600 hover:text-pink-500 hover:bg-pink-50 rounded-lg transition-colors"
                        >
                          {copiedCode ? <Check size={20} /> : <Copy size={20} />}
                        </button>
                      </div>
                      {copiedCode && (
                        <p className="text-green-600 text-sm mt-1 flex items-center gap-1">
                          <Check size={16} /> Copied to clipboard!
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <div className="flex-shrink-0 w-8 h-8 bg-pink-500 text-white rounded-full flex items-center justify-center font-bold text-sm">
                      2
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-gray-900 mb-1">Send an email from your email address</p>
                      <p className="text-sm text-gray-600 mb-2">
                        Use your email client to send an email with:
                      </p>
                      <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 space-y-2 text-sm">
                        <div>
                          <span className="font-medium text-blue-900">To:</span>
                          <span className="ml-2 text-blue-800">verify@workmatch.com</span>
                        </div>
                        <div>
                          <span className="font-medium text-blue-900">Subject:</span>
                          <span className="ml-2 text-blue-800">{verificationCode}</span>
                        </div>
                        <div>
                          <span className="font-medium text-blue-900">Body:</span>
                          <span className="ml-2 text-gray-600">(can be empty)</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <div className="flex-shrink-0 w-8 h-8 bg-pink-500 text-white rounded-full flex items-center justify-center font-bold text-sm">
                      3
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-gray-900 mb-1">Wait for verification</p>
                      <p className="text-sm text-gray-600">
                        We'll verify your email automatically when we receive it. This usually takes less than a minute.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="border-t border-gray-200 pt-4">
                  <div className="flex items-center justify-center gap-2 text-gray-600 mb-4">
                    <div className="w-2 h-2 bg-pink-500 rounded-full animate-pulse"></div>
                    <span className="text-sm">Waiting for your email...</span>
                  </div>

                  <button
                    onClick={handleWorkEmailVerified}
                    className="w-full bg-gray-100 text-gray-700 py-2 rounded-lg text-sm font-medium hover:bg-gray-200 transition-colors"
                  >
                    Demo: Skip verification
                  </button>
                </div>
              </div>

              <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg mt-6 w-full">
                <p className="text-sm text-yellow-900">
                  <strong>Important:</strong> Make sure to send from <strong>{matchingEmail}</strong> for verification to succeed.
                </p>
              </div>
            </main>
          </div>
        );
      }

      if (matchingEmailScreen === 'verified') {
        return (
          <div className="size-full bg-gray-50 flex flex-col max-w-md mx-auto">
            <div className="flex-1 flex flex-col items-center justify-center px-6">
              <div className="bg-green-500 text-white p-6 rounded-full mb-8">
                <Check size={48} />
              </div>

              <h2 className="text-3xl font-bold text-gray-900 mb-2 text-center">Verified!</h2>
              <p className="text-gray-600 text-center mb-8">
                Your email has been verified successfully
              </p>

              <div className="w-full bg-white p-6 rounded-lg shadow-sm mb-6">
                <div className="flex flex-col gap-2">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Email:</span>
                    <span className="font-medium text-gray-900">{matchingEmail}</span>
                  </div>
                </div>
              </div>

              <p className="text-sm text-gray-500 text-center">
                Redirecting to dashboard...
              </p>
            </div>
          </div>
        );
      }
    }

    // Add Interest Screen
    if (currentScreen === 'add-interest') {
      return (
        <div className="size-full bg-gray-50 flex flex-col max-w-md mx-auto">
          <header className="bg-white border-b border-gray-200 px-4 py-4 flex items-center gap-3">
            <button onClick={() => {
              handleCancelEdit();
              setCurrentScreen('dashboard');
            }} className="p-2 hover:bg-gray-100 rounded-lg">
              <X size={20} />
            </button>
            <h1 className="text-lg font-semibold text-gray-900">Manage Interests</h1>
          </header>

          <main className="flex-1 overflow-y-auto p-4">
            <div className="space-y-4">
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h2 className="font-semibold text-lg mb-2">{editingInterestId ? 'Edit Interest' : 'Express Interest'}</h2>
                <p className="text-sm text-gray-600 mb-4">
                  {editingInterestId ? 'Update the details below.' : 'Enter the details of someone you\'re interested in. They\'ll only know if they add you too.'}
                </p>

                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        First name
                      </label>
                      <input
                        type="text"
                        value={interestFirstName}
                        onChange={(e) => setInterestFirstName(e.target.value)}
                        placeholder="Sarah"
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Surname
                      </label>
                      <input
                        type="text"
                        value={interestSurname}
                        onChange={(e) => setInterestSurname(e.target.value)}
                        placeholder="Johnson"
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Email address
                    </label>
                    <input
                      type="email"
                      value={interestEmail}
                      onChange={(e) => setInterestEmail(e.target.value)}
                      placeholder="colleague@company.com"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent outline-none"
                    />
                  </div>

                  {emailError && <p className="text-red-500 text-sm">{emailError}</p>}

                  <div className="flex gap-3">
                    <button
                      onClick={handleAddInterest}
                      className="flex-1 bg-pink-500 text-white py-3 rounded-lg font-semibold hover:bg-pink-600 transition-colors"
                    >
                      {editingInterestId ? 'Update Interest' : 'Add Interest'}
                    </button>
                    {editingInterestId && (
                      <button
                        onClick={handleCancelEdit}
                        className="px-6 bg-gray-200 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-300 transition-colors"
                      >
                        Cancel
                      </button>
                    )}
                  </div>
                </div>

                {showSuccess && (
                  <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2 text-green-700">
                    <Check size={20} />
                    <span className="text-sm">{editingInterestId ? 'Interest updated successfully!' : 'Interest added successfully!'}</span>
                  </div>
                )}
              </div>

              <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg">
                <h3 className="font-medium text-blue-900 mb-2">How it works</h3>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• Your interest is completely anonymous</li>
                  <li>• They won't know unless they add you too</li>
                  <li>• Both of you get notified when there's a match</li>
                  <li>• Works with any of your verified matching emails</li>
                </ul>
              </div>

              {interests.length > 0 && (
                <div className="space-y-3">
                  <h3 className="font-semibold text-lg">Your Interests ({interests.length})</h3>
                  {interests.map((interest) => (
                    <div key={interest.id} className={`bg-white p-4 rounded-lg shadow-sm ${editingInterestId === interest.id ? 'border-2 border-pink-400' : ''}`}>
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <p className="font-medium text-gray-900">{interest.firstName} {interest.surname}</p>
                          <p className="text-sm text-gray-600">{interest.email}</p>
                          <p className="text-xs text-gray-500 mt-1">
                            Added {interest.timestamp.toLocaleDateString()}
                          </p>
                        </div>
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleEditInterest(interest)}
                            className="p-2 text-gray-400 hover:text-pink-500 hover:bg-pink-50 rounded-lg transition-colors"
                            title="Edit"
                          >
                            <Edit2 size={20} />
                          </button>
                          <button
                            onClick={() => handleDeleteInterest(interest.id)}
                            className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                            title="Delete"
                          >
                            <X size={20} />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </main>
        </div>
      );
    }

    // Matches Screen
    if (currentScreen === 'matches') {
      return (
        <div className="size-full bg-gray-50 flex flex-col max-w-md mx-auto">
          <header className="bg-white border-b border-gray-200 px-4 py-4 flex items-center gap-3">
            <button onClick={() => setCurrentScreen('dashboard')} className="p-2 hover:bg-gray-100 rounded-lg">
              <X size={20} />
            </button>
            <h1 className="text-lg font-semibold text-gray-900">Your Matches</h1>
          </header>

          <main className="flex-1 overflow-y-auto p-4">
            {matches.length === 0 ? (
              <div className="bg-white p-8 rounded-lg shadow-sm text-center">
                <Heart size={48} className="mx-auto text-gray-300 mb-3" />
                <p className="text-gray-500 mb-2">No matches yet</p>
                <p className="text-sm text-gray-400">
                  When someone you're interested in adds you back, you'll see them here!
                </p>
                <button
                  onClick={() => setCurrentScreen('add-interest')}
                  className="mt-4 text-pink-500 font-medium hover:underline"
                >
                  Add an interest
                </button>
              </div>
            ) : (
              <div className="space-y-6">
                {/* New Matches Section */}
                {matches.filter(m => m.isNew).length > 0 && (
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <h2 className="font-semibold text-lg text-gray-900">New Matches</h2>
                      <span className="bg-pink-500 text-white text-xs px-2 py-1 rounded-full font-medium">
                        {matches.filter(m => m.isNew).length}
                      </span>
                    </div>

                    {matches.filter(m => m.isNew).map((match) => (
                      <div key={match.id} className="bg-gradient-to-r from-pink-50 to-purple-50 rounded-lg border-2 border-pink-400 overflow-hidden shadow-md">
                        <div className="p-4">
                          <div className="flex items-start gap-3">
                            <div className="bg-pink-500 text-white p-2 rounded-full animate-pulse">
                              <Heart size={20} fill="currentColor" />
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <p className="font-semibold text-gray-900">It's a match!</p>
                                <span className="bg-pink-500 text-white text-xs px-2 py-0.5 rounded-full font-medium">
                                  NEW
                                </span>
                              </div>
                              <p className="text-lg font-medium text-gray-900">{match.firstName} {match.surname}</p>
                              <p className="text-sm text-gray-700">{match.email}</p>
                              <p className="text-xs text-gray-500 mt-1">
                                Matched on {match.matchedAt.toLocaleDateString()}
                              </p>
                            </div>
                          </div>
                        </div>

                        <div className="px-4 py-3 bg-white border-t border-pink-200 space-y-2">
                          <button
                            onClick={() => handleMarkAsRead(match.id)}
                            className="w-full py-2 px-4 rounded-lg font-medium bg-gray-100 text-gray-700 hover:bg-gray-200 transition-colors flex items-center justify-center gap-2"
                          >
                            <Check size={16} />
                            Mark as Read
                          </button>

                          <button
                            onClick={() => handleShareMobile(match.id)}
                            className={`w-full py-2 px-4 rounded-lg font-medium transition-colors ${
                              match.mobileShared
                                ? 'bg-green-100 text-green-700 hover:bg-green-200'
                                : 'bg-pink-500 text-white hover:bg-pink-600'
                            }`}
                          >
                            {match.mobileShared ? (
                              <span className="flex items-center justify-center gap-2">
                                <Check size={16} />
                                Mobile Shared: {userProfile.mobileNumber}
                              </span>
                            ) : (
                              'Share My Mobile Number'
                            )}
                          </button>
                          {match.mobileShared && (
                            <p className="text-xs text-gray-500 text-center">
                              They can now see your mobile number
                            </p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Previous Matches Section */}
                {matches.filter(m => !m.isNew).length > 0 && (
                  <div className="space-y-3">
                    <h2 className="font-semibold text-lg text-gray-900">Previous Matches</h2>

                    {matches.filter(m => !m.isNew).map((match) => (
                      <div key={match.id} className="bg-gradient-to-r from-pink-50 to-purple-50 rounded-lg border-2 border-pink-200 overflow-hidden">
                        <div className="p-4">
                          <div className="flex items-start gap-3">
                            <div className="bg-pink-500 text-white p-2 rounded-full">
                              <Heart size={20} fill="currentColor" />
                            </div>
                            <div className="flex-1">
                              <p className="font-semibold text-gray-900 mb-1">It's a match!</p>
                              <p className="text-lg font-medium text-gray-900">{match.firstName} {match.surname}</p>
                              <p className="text-sm text-gray-700">{match.email}</p>
                              <p className="text-xs text-gray-500 mt-1">
                                Matched on {match.matchedAt.toLocaleDateString()}
                              </p>
                            </div>
                          </div>
                        </div>

                        <div className="px-4 py-3 bg-white border-t border-pink-100">
                          <button
                            onClick={() => handleShareMobile(match.id)}
                            className={`w-full py-2 px-4 rounded-lg font-medium transition-colors ${
                              match.mobileShared
                                ? 'bg-green-100 text-green-700 hover:bg-green-200'
                                : 'bg-pink-500 text-white hover:bg-pink-600'
                            }`}
                          >
                            {match.mobileShared ? (
                              <span className="flex items-center justify-center gap-2">
                                <Check size={16} />
                                Mobile Shared: {userProfile.mobileNumber}
                              </span>
                            ) : (
                              'Share My Mobile Number'
                            )}
                          </button>
                          {match.mobileShared && (
                            <p className="text-xs text-gray-500 text-center mt-2">
                              They can now see your mobile number
                            </p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </main>
        </div>
      );
    }

    // Settings Screen
    if (currentScreen === 'settings') {
      return (
        <div className="size-full bg-gray-50 flex flex-col max-w-md mx-auto">
          <header className="bg-white border-b border-gray-200 px-4 py-4 flex items-center gap-3">
            <button onClick={() => setCurrentScreen('dashboard')} className="p-2 hover:bg-gray-100 rounded-lg">
              <X size={20} />
            </button>
            <h1 className="text-lg font-semibold text-gray-900">Settings</h1>
          </header>

          <main className="flex-1 overflow-y-auto p-4 space-y-4">
            {/* Notifications Section */}
            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="px-4 py-3 border-b border-gray-200">
                <h2 className="font-semibold text-gray-900">Notifications</h2>
                <p className="text-sm text-gray-500 mt-1">What to do when I have a new match</p>
              </div>

              <div className="divide-y divide-gray-200">
                {/* Push Notification Toggle */}
                <div className="px-4 py-4 flex items-center justify-between">
                  <div className="flex items-center gap-3 flex-1">
                    <div className="bg-purple-100 p-2 rounded-lg">
                      <Smartphone size={20} className="text-purple-600" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">Push notification to my mobile</p>
                      <p className="text-xs text-gray-500 mt-0.5">Get instant alerts on your phone</p>
                    </div>
                  </div>
                  <button
                    onClick={() => handleToggleNotification('push')}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                      userProfile.notifyViaPush ? 'bg-pink-500' : 'bg-gray-300'
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        userProfile.notifyViaPush ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>

                {/* Email Notification Toggle */}
                <div className="px-4 py-4 flex items-center justify-between">
                  <div className="flex items-center gap-3 flex-1">
                    <div className="bg-blue-100 p-2 rounded-lg">
                      <Mail size={20} className="text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">Send me an email</p>
                      <p className="text-xs text-gray-500 mt-0.5">Receive notifications via email</p>
                    </div>
                  </div>
                  <button
                    onClick={() => handleToggleNotification('email')}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                      userProfile.notifyViaEmail ? 'bg-pink-500' : 'bg-gray-300'
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        userProfile.notifyViaEmail ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>
              </div>
            </div>

            {/* Info Message */}
            {!userProfile.notifyViaPush && !userProfile.notifyViaEmail && (
              <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg">
                <p className="text-sm text-yellow-900">
                  <strong>Note:</strong> You won't receive notifications about new matches until you enable at least one notification method.
                </p>
              </div>
            )}

            {/* Account Info */}
            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="px-4 py-3 border-b border-gray-200">
                <h2 className="font-semibold text-gray-900">Account Information</h2>
              </div>

              <div className="px-4 py-4 space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Name:</span>
                  <span className="font-medium text-gray-900">{userProfile.firstName} {userProfile.surname}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Personal Email:</span>
                  <span className="font-medium text-gray-900">{userProfile.personalEmail}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Mobile:</span>
                  <span className="font-medium text-gray-900">{userProfile.mobileNumber}</span>
                </div>
              </div>
            </div>

            {/* Matching Emails Section */}
            {userProfile.matchingEmails.length > 0 && (
              <div className="bg-white rounded-lg shadow-sm overflow-hidden">
                <div className="px-4 py-3 border-b border-gray-200">
                  <h2 className="font-semibold text-gray-900">Matching Emails</h2>
                  <p className="text-sm text-gray-500 mt-1">Your verified email addresses for matching</p>
                </div>

                <div className="px-4 py-4 space-y-3">
                  {userProfile.matchingEmails.map((email) => (
                    <div key={email.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex-1">
                        <p className="font-medium text-gray-900">{email.email}</p>
                        <p className="text-xs text-gray-500 mt-0.5">
                          {email.type === 'work' ? 'Work' : 'University'} • Added {email.addedAt.toLocaleDateString()}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="bg-green-100 text-green-700 px-2 py-1 rounded text-xs font-medium">
                          Verified
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="px-4 py-3 border-t border-gray-200 bg-gray-50">
                  <button
                    onClick={() => setCurrentScreen('add-work-email')}
                    className="text-sm text-purple-600 font-medium hover:underline"
                  >
                    Manage matching emails →
                  </button>
                </div>
              </div>
            )}
          </main>
        </div>
      );
    }
  }

  // Auth screens - only show if not authenticated
  // Welcome Screen
  if (authScreen === 'welcome') {
    return (
      <div className="size-full bg-gradient-to-br from-pink-50 to-purple-50 flex flex-col max-w-md mx-auto">
        <div className="flex-1 flex flex-col items-center justify-center px-6">
          <div className="bg-pink-500 text-white p-6 rounded-full mb-8">
            <Heart size={48} fill="currentColor" />
          </div>

          <h1 className="text-3xl font-bold text-gray-900 mb-2 text-center">WorkMatch</h1>
          <p className="text-gray-600 text-center mb-12">
            Express interest anonymously. Get notified only when it's mutual.
          </p>

          <div className="w-full space-y-3">
            <button
              onClick={() => setAuthScreen('login')}
              className="w-full bg-pink-500 text-white py-3 rounded-lg font-semibold hover:bg-pink-600 transition-colors"
            >
              Log In
            </button>

            <button
              onClick={() => setAuthScreen('register')}
              className="w-full bg-white text-pink-500 py-3 rounded-lg font-semibold border-2 border-pink-500 hover:bg-pink-50 transition-colors"
            >
              Create Account
            </button>
          </div>

          <p className="text-xs text-gray-500 text-center mt-12 px-4">
            Your identity remains private until there's a mutual match
          </p>
        </div>
      </div>
    );
  }

  // Login Screen
  if (authScreen === 'login') {
    return (
      <div className="size-full bg-gradient-to-br from-pink-50 to-purple-50 flex flex-col max-w-md mx-auto">
        <div className="flex-1 flex flex-col items-center justify-center px-6">
          <div className="bg-pink-500 text-white p-6 rounded-full mb-8">
            <Heart size={48} fill="currentColor" />
          </div>

          <h1 className="text-2xl font-bold text-gray-900 mb-2 text-center">Welcome Back</h1>
          <p className="text-gray-600 text-center mb-8">
            Log in to your WorkMatch account
          </p>

          <div className="w-full space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Email address
              </label>
              <input
                type="email"
                value={loginEmail}
                onChange={(e) => {
                  setLoginEmail(e.target.value);
                  setEmailError('');
                }}
                onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                placeholder="you@personal.com"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Password
              </label>
              <input
                type="password"
                value={loginPassword}
                onChange={(e) => {
                  setLoginPassword(e.target.value);
                  setEmailError('');
                }}
                onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                placeholder="••••••••"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent outline-none"
              />
            </div>

            {emailError && <p className="text-red-500 text-sm">{emailError}</p>}

            <button
              onClick={handleLogin}
              className="w-full bg-pink-500 text-white py-3 rounded-lg font-semibold hover:bg-pink-600 transition-colors"
            >
              Log In
            </button>

            <button
              onClick={() => {
                setAuthScreen('welcome');
                setEmailError('');
              }}
              className="w-full text-gray-600 py-2 text-sm hover:text-gray-900"
            >
              Back to Welcome
            </button>

            <div className="bg-blue-50 border border-blue-200 p-3 rounded-lg mt-4">
              <p className="text-xs text-blue-900">
                <strong>Demo:</strong> Enter any email and password to log in
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Register Screen
  if (authScreen === 'register') {
    return (
      <div className="size-full bg-gradient-to-br from-pink-50 to-purple-50 flex flex-col max-w-md mx-auto overflow-y-auto">
        <div className="flex-1 flex flex-col items-center justify-center px-6 py-8">
          <div className="bg-pink-500 text-white p-6 rounded-full mb-8">
            <UserPlus size={48} />
          </div>

          <h1 className="text-2xl font-bold text-gray-900 mb-2 text-center">Create Account</h1>
          <p className="text-gray-600 text-center mb-8">
            Join WorkMatch to find mutual connections
          </p>

          <div className="w-full space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  First name
                </label>
                <input
                  type="text"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  placeholder="Sarah"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Surname
                </label>
                <input
                  type="text"
                  value={surname}
                  onChange={(e) => setSurname(e.target.value)}
                  placeholder="Johnson"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Mobile number
              </label>
              <input
                type="tel"
                value={mobileNumber}
                onChange={(e) => setMobileNumber(e.target.value)}
                placeholder="+1 555-0123"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Personal email
              </label>
              <input
                type="email"
                value={personalEmail}
                onChange={(e) => setPersonalEmail(e.target.value)}
                placeholder="you@personal.com"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Password
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent outline-none"
              />
            </div>

            {emailError && <p className="text-red-500 text-sm">{emailError}</p>}

            <button
              onClick={handleRegister}
              className="w-full bg-pink-500 text-white py-3 rounded-lg font-semibold hover:bg-pink-600 transition-colors"
            >
              Create Account
            </button>

            <button
              onClick={() => setAuthScreen('welcome')}
              className="w-full text-gray-600 py-2 text-sm hover:text-gray-900"
            >
              Back to Welcome
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Mobile Verification Screen
  if (authScreen === 'mobile-verification') {
    return (
      <div className="size-full bg-gradient-to-br from-pink-50 to-purple-50 flex flex-col max-w-md mx-auto">
        <div className="flex-1 flex flex-col items-center justify-center px-6">
          <div className="bg-purple-500 text-white p-6 rounded-full mb-8">
            <Smartphone size={48} />
          </div>

          <h1 className="text-2xl font-bold text-gray-900 mb-2 text-center">Verify Mobile Number</h1>
          <p className="text-gray-600 text-center mb-8">
            We've sent a verification code to:
          </p>

          <div className="w-full bg-white p-4 rounded-lg shadow-sm mb-8">
            <p className="text-center font-medium text-gray-900">{mobileNumber}</p>
          </div>

          <div className="w-full bg-blue-50 border border-blue-200 p-4 rounded-lg mb-6">
            <p className="text-sm text-blue-900 font-medium mb-2">Demo Mode</p>
            <p className="text-sm text-blue-800">
              Your verification code is: <span className="font-bold text-lg">{mobileVerificationCode}</span>
            </p>
          </div>

          <div className="w-full space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Enter verification code
              </label>
              <input
                type="text"
                value={enteredMobileCode}
                onChange={(e) => setEnteredMobileCode(e.target.value)}
                placeholder="000000"
                maxLength={6}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none text-center text-2xl tracking-widest font-bold"
              />
              {emailError && <p className="text-red-500 text-sm mt-1">{emailError}</p>}
            </div>

            <button
              onClick={handleVerifyMobile}
              className="w-full bg-purple-500 text-white py-3 rounded-lg font-semibold hover:bg-purple-600 transition-colors"
            >
              Verify Mobile
            </button>

            <button
              onClick={() => setAuthScreen('register')}
              className="w-full bg-white text-gray-700 py-3 rounded-lg font-semibold border border-gray-300 hover:bg-gray-50 transition-colors"
            >
              Back to Registration
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Email Verification Sent Screen
  if (authScreen === 'email-verification-sent') {
    return (
      <div className="size-full bg-gradient-to-br from-pink-50 to-purple-50 flex flex-col max-w-md mx-auto">
        <div className="flex-1 flex flex-col items-center justify-center px-6">
          <div className="bg-green-500 text-white p-6 rounded-full mb-8">
            <Mail size={48} />
          </div>

          <h1 className="text-2xl font-bold text-gray-900 mb-2 text-center">Verify Your Email</h1>
          <p className="text-gray-600 text-center mb-8">
            We've sent a verification email to:
          </p>

          <div className="w-full bg-white p-4 rounded-lg shadow-sm mb-8">
            <p className="text-center font-medium text-gray-900">{personalEmail}</p>
          </div>

          <div className="w-full bg-blue-50 border border-blue-200 p-4 rounded-lg space-y-3">
            <p className="text-sm text-blue-900">
              <strong>Next steps:</strong>
            </p>
            <ol className="text-sm text-blue-800 space-y-1 ml-4">
              <li>1. Check your email inbox</li>
              <li>2. Click the verification link</li>
              <li>3. Return here to log in</li>
            </ol>
          </div>

          <button
            onClick={() => setAuthScreen('login')}
            className="w-full mt-8 bg-pink-500 text-white py-3 rounded-lg font-semibold hover:bg-pink-600 transition-colors"
          >
            Go to Login
          </button>

          <p className="text-xs text-gray-500 text-center mt-4">
            Your account will be active once you verify your email
          </p>
        </div>
      </div>
    );
  }

}
